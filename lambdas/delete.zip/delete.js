const AWS = require("aws-sdk"); 

module.exports.handler = async (event, context) => {
	try{
		return {
			statusCode: 200,
			body: JSON.stringify(event),
		};
	} catch(err){
		return {
			statusCode: 500,
			body: JSON.stringify(err)
		};
	}
};

